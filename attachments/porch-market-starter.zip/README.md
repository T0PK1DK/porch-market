# Porch Market — Starter Build

A simple free-storefront local marketplace prototype for home vendors and cottage food makers.

## What this is
- Browse page with sample Miami-area vendors
- Individual storefront pages (name, bio, location, products)
- “Create Free Storefront” form that saves to browser localStorage (demo only)
- Mobile-friendly, no backend yet

## How to run
1. Download the files (or open the folder).
2. Open `index.html` in any browser.
3. Click vendors to see their storefronts.
4. Use “Create Your Free Storefront” to add one — it appears immediately in the browse list (only in your browser).

## Files
- `index.html` — main browse page
- `storefront.html` — individual vendor page
- `create.html` — simple creation form
- `styles.css` — styling
- `app.js` — data + rendering logic

## Next steps we can add later
- Real backend / auth so storefronts persist
- Stripe Connect for free checkout with low fees
- Map / zip search
- Image uploads
- Order management & pickup scheduling
- Cottage food label helpers
- Florida-specific compliance notes

This is intentionally lightweight so we can iterate quickly.
