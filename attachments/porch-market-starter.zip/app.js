// Sample data for the starter build
const sampleVendors = [
  {
    id: "miami-sourdough",
    name: "Bayfront Sourdough",
    location: "Miami Beach, FL",
    category: "Baked Goods",
    bio: "Weekend sourdough loaves and focaccia baked in a home kitchen. Porch pickup Saturdays.",
    image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800&q=80",
    products: [
      { name: "Country Sourdough Loaf", price: "$12", desc: "Classic tangy loaf, feeds 2–3.", image: "https://images.unsplash.com/photo-1549931319-a545dcf3bc73?w=400&q=80" },
      { name: "Rosemary Focaccia", price: "$10", desc: "Olive oil + sea salt, same-day only.", image: "https://images.unsplash.com/photo-1608198093002-ad4e005484ec?w=400&q=80" }
    ]
  },
  {
    id: "keys-honey",
    name: "Keys Honey Co.",
    location: "Homestead, FL",
    category: "Honey & Preserves",
    bio: "Local wildflower honey and small-batch jams. Pickup or local drop-off.",
    image: "https://images.unsplash.com/photo-1558642452-9d2a7deb7f62?w=800&q=80",
    products: [
      { name: "Wildflower Honey 12oz", price: "$14", desc: "Raw, unfiltered.", image: "https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=400&q=80" },
      { name: "Mango Jam", price: "$9", desc: "Seasonal, low-sugar.", image: "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?w=400&q=80" }
    ]
  },
  {
    id: "porch-cookies",
    name: "Porch Cookie Drop",
    location: "Coral Gables, FL",
    category: "Baked Goods",
    bio: "Small-batch cookies. Pre-order for Friday or Saturday porch pickup.",
    image: "https://images.unsplash.com/photo-1499636136210-6f4ee915583e?w=800&q=80",
    products: [
      { name: "Chocolate Chip Dozen", price: "$16", desc: "Brown butter version.", image: "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400&q=80" },
      { name: "Oatmeal Raisin Half Dozen", price: "$9", desc: "Chewy, not dry.", image: "https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?w=400&q=80" }
    ]
  }
];

function getVendors() {
  const stored = localStorage.getItem("porchVendors");
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch (e) {}
  }
  return sampleVendors;
}

function saveVendors(vendors) {
  localStorage.setItem("porchVendors", JSON.stringify(vendors));
}

function renderVendorGrid() {
  const grid = document.getElementById("vendor-grid");
  if (!grid) return;
  const vendors = getVendors();
  grid.innerHTML = vendors.map(v => `
    <div class="card">
      <img src="${v.image}" alt="${v.name}" />
      <div class="card-body">
        <h3>${v.name}</h3>
        <div class="meta">${v.category} · ${v.location}</div>
        <p>${v.bio.slice(0, 90)}${v.bio.length > 90 ? "…" : ""}</p>
        <a class="btn" href="storefront.html?id=${v.id}">View Storefront</a>
      </div>
    </div>
  `).join("");
}

function renderStorefront() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");
  const vendors = getVendors();
  const vendor = vendors.find(v => v.id === id);
  const container = document.getElementById("storefront");
  if (!container) return;

  if (!vendor) {
    container.innerHTML = "<p>Vendor not found. <a href='index.html'>Back to browse</a></p>";
    return;
  }

  container.innerHTML = `
    <div class="hero">
      <img src="${vendor.image}" alt="${vendor.name}" style="width:100%; max-height:280px; object-fit:cover; border-radius:8px; margin-bottom:1rem;" />
      <h2>${vendor.name}</h2>
      <p class="meta">${vendor.category} · ${vendor.location}</p>
      <p>${vendor.bio}</p>
    </div>
    <h3>Available now</h3>
    <div class="product-list">
      ${vendor.products.map(p => `
        <div class="product">
          <img src="${p.image}" alt="${p.name}" />
          <div>
            <strong>${p.name}</strong>
            <div class="price">${p.price}</div>
            <p>${p.desc}</p>
          </div>
        </div>
      `).join("")}
    </div>
    <p style="margin-top:1.5rem;"><a class="btn" href="index.html">← Back to all vendors</a></p>
  `;
}

// Create form handling
function setupCreateForm() {
  const form = document.getElementById("create-form");
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const vendors = getVendors();
    const newVendor = {
      id: "custom-" + Date.now(),
      name: form.name.value.trim(),
      location: form.location.value.trim(),
      category: form.category.value,
      bio: form.bio.value.trim(),
      image: form.image.value.trim() || "https://images.unsplash.com/photo-1464226184884-fa280b210c07?w=800&q=80",
      products: [
        {
          name: form.productName.value.trim() || "Sample Product",
          price: form.productPrice.value.trim() || "$10",
          desc: form.productDesc.value.trim() || "Available for local pickup.",
          image: "https://images.unsplash.com/photo-1506617420156-8e4536971650?w=400&q=80"
        }
      ]
    };
    vendors.unshift(newVendor);
    saveVendors(vendors);
    alert("Storefront created! (saved in this browser for the demo)");
    window.location.href = "storefront.html?id=" + newVendor.id;
  });
}

// Init
document.addEventListener("DOMContentLoaded", () => {
  renderVendorGrid();
  renderStorefront();
  setupCreateForm();
});
